	
	
	function f3() {
		let sil = document.getElementsByClassName('sil');
		let art = document.getElementsByTagName('article');
		
		for (let i=0; i<sil.length; i++)
		sil[i].onclick = function() 
		{

			for (let j=i+1; j<sil.length;j++)
				art[j].style.display="none";
			art[i].style.flexDirection="column";
			art[i].getElementsByTagName('div')[0].style.width="auto";
			art[i].getElementsByTagName('h4')[0].style.fontSize="20px";
			art[i].getElementsByTagName('p')[0].style.fontSize="17px";
			art[i].style.height="auto";
			sil[i].blur();

						
		}

		let con = document.getElementsByTagName('input')[0];
		con.onchange = function () 
		
		{
			let fin=con.value;
			let elem = [
			document.getElementsByTagName('h1'),
			document.getElementsByTagName('h3'),
			document.getElementsByTagName('h4'),
			document.getElementsByTagName('p'),
			document.getElementsByTagName('a'),
			
			]
			
			for (let j=0;j<5;j++)
				for (let i=0;i<elem[j].length;i++)
				{
					
					if ((elem[j][i].textContent.indexOf(fin)!=-1)&&(fin!=''))
					{
						con.blur();
						elem[j][i].focus();
					}
				}
		}
		
	}