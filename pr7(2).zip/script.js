	
	
	function f3() {
		let sil = document.getElementsByClassName('sil');
		let art = document.getElementsByTagName('article');
		
		for (let i=0; i<sil.length; i++)
		sil[i].onclick = function() 
		{

			for (let j=i+1; j<sil.length;j++)
				art[j].style.visibility="hidden";
				
				
			if (i<3) art[3].style.display="none";
			art[i].style.flexDirection="column";
			art[i].getElementsByTagName('div')[0].style.width="auto";
			art[i].getElementsByTagName('h4')[0].style.fontSize="20px";
			art[i].getElementsByTagName('p')[0].style.fontSize="17px";
			art[i].style.height="auto";
			sil[i].blur();

						
		}
		
		
		let con = document.getElementsByTagName('input')[0];
		con.onchange = function () 
		
		{
			let fin=con.value;
			let elem = [
			document.getElementsByTagName('h1'),
			document.getElementsByTagName('h3'),
			document.getElementsByTagName('h4'),
			document.getElementsByTagName('p'),
			document.getElementsByTagName('a'),
			
			]
			
			for (let j=0;j<5;j++)
				for (let i=0;i<elem[j].length;i++)
				{
					
					if ((elem[j][i].textContent.indexOf(fin)!=-1)&&(fin!=''))
					{
						elem[j][i].setAttribute('tabindex', '0');
						con.blur();
						elem[j][i].onfocus = function () {elem[j][i].style.backgroundColor="rgba(68, 19, 77, 0.5";}	
						elem[j][i].onblur = function () {elem[j][i].style.backgroundColor="rgba(0,0,0,0)"; elem[j][i].removeAttribute('tabindex')}
						elem[j][i].focus();
						
					}
				}
		}
		
	}